﻿using System;
using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class PowerController : MonoBehaviour
{
    public float speed = 40f;
    public int damage = 0;
    public Rigidbody2D rigidBody;
    public GameObject impactEffect;
    private GameObject iE = null;
    private AudioSource audioSource;
    private AudioClip clip;


    // Start is called before the first frame update
    void Start()
    {
        rigidBody.velocity = transform.right * speed;
        audioSource = transform.GetComponentInParent<AudioSource>();
        clip = audioSource.clip;
    }

    private void OnTriggerEnter2D(Collider2D hitInfo)
    {
        if (gameObject.name == "PlayerPower(Clone)" && hitInfo.gameObject.name == "AI" ||
            gameObject.name == "AIPower(Clone)" && hitInfo.gameObject.name == "Player")
        {
            HealthController healthController = hitInfo.GetComponent<HealthController>();
            if (healthController != null)
            {
                healthController.TakeDamage(damage);
                iE = Instantiate(impactEffect, transform.position, transform.rotation);
                audioSource.PlayOneShot(clip, 0.7f);
            }

            Destroy(gameObject);
        }
    }

    // Update is called once per frame
    void Update()
    {
    }
}