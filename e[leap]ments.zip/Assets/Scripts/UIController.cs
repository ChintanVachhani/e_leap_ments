﻿using System;
using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.SceneManagement;
using UnityEngine.UI;

public class UIController : MonoBehaviour
{
    public GameObject Player;
    public GameObject AI;

    private GameObject playerHealth;
    private GameObject aiHealth;
    private Transform notification;
    private GameObject restartButton;
    private GameObject exitButton;
    private GameObject elements;
    [HideInInspector] public GameObject plus1, plus2, plus3;
    [HideInInspector] public GameObject air, fire, earth, water;

    // Start is called before the first frame update
    void Start()
    {
        playerHealth = transform.GetChild(1).transform.GetChild(0).gameObject;
        aiHealth = transform.GetChild(2).transform.GetChild(0).gameObject;
        notification = transform.GetChild(3);
        notification.gameObject.SetActive(false);
        restartButton = transform.GetChild(5).gameObject;
        restartButton.SetActive(false);
        exitButton = transform.GetChild(6).gameObject;
        exitButton.SetActive(false);
        elements = transform.GetChild(4).gameObject;
//        elements.SetActive(false);
        air = elements.transform.GetChild(0).gameObject;
        fire = elements.transform.GetChild(1).gameObject;
        earth = elements.transform.GetChild(2).gameObject;
        water = elements.transform.GetChild(3).gameObject;
        plus1 = elements.transform.GetChild(4).gameObject;
        plus2 = elements.transform.GetChild(5).gameObject;
        plus3 = elements.transform.GetChild(6).gameObject;
        air.gameObject.SetActive(false);
        fire.gameObject.SetActive(false);
        earth.gameObject.SetActive(false);
        water.gameObject.SetActive(false);
        plus1.gameObject.SetActive(true);
        plus2.gameObject.SetActive(true);
        plus3.gameObject.SetActive(true);
    }

    // Update is called once per frame
    void Update()
    {
        if (Player == null)
        {
            playerHealth.GetComponent<Text>().text = "0";
            notification.GetComponent<Text>().text = "Game Over!";
            notification.gameObject.SetActive(true);
            restartButton.SetActive(true);
            exitButton.SetActive(true);
        }
        else if (AI == null)
        {
            notification.GetComponent<Text>().text = "Excellent!";
            notification.gameObject.SetActive(true);
            restartButton.SetActive(true);
            exitButton.SetActive(true);
            aiHealth.GetComponent<Text>().text = "0";
        }
        else
        {
            playerHealth.GetComponent<Text>().text = Player.GetComponent<HealthController>().health.ToString();
            aiHealth.GetComponent<Text>().text = AI.GetComponent<HealthController>().health.ToString();
        }
    }
}