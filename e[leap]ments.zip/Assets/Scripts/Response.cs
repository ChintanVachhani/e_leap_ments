[System.Serializable]
public class UserResponse
{
    public int score;
}

[System.Serializable]
public class AIResponse
{
    public int score;
    public string action;
}

[System.Serializable]
public class Response<T>
{
    public string message;
    public T data;
}

[System.Serializable]
public class ErrorResponse
{
    public string message;
}