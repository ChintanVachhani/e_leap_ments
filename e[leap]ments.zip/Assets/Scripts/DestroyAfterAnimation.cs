﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class DestroyAfterAnimation : MonoBehaviour
{
    public float time;
    
    private IEnumerator KillOnAnimationEnd() {
        yield return new WaitForSeconds (time);
        Destroy (gameObject);
    }
 
    void Update () {
        StartCoroutine (KillOnAnimationEnd ());
    }
}
