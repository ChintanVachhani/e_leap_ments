﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class AIActionController : MonoBehaviour
{
    public Transform firePoint;
    public GameObject playerPowerPrefab;

    // Update is called once per frame
    void Update()
    {
        /*if (Input.GetButtonDown("Fire2"))
        {
            Attack(40);
        }*/
    }

    public void Attack(int damage)
    {
        GameObject playerPower = Instantiate(playerPowerPrefab, firePoint.position, firePoint.rotation);
        playerPower.GetComponent<PowerController>().damage = damage;
    }
}