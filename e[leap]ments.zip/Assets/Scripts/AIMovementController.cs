﻿using System;
using System.Collections;
using System.Collections.Generic;
using System.Text;
using UnityEngine;
using UnityEngine.UI;

public class AIMovementController : MonoBehaviour
{
    public CharacterController2D controller;
    public Animator animator;

    private float horizontalMove = 0f;
    private bool jump = false;
    private bool crouch = false;

    private bool alreadyAttacking;

    public Transform player;
    public GameObject notification;

    // Start is called before the first frame update
    void Start()
    {
        alreadyAttacking = false;
    }

    // Update is called once per frame
    void Update()
    {
        // horizontalMove = Input.GetAxisRaw("Horizontal"); // comment to stop horizontal movement

        if (Input.GetButtonDown("Jump2"))
        {
            jump = true;
            animator.SetBool("IsJumping", true);
        }

        /*if (Input.GetButtonDown("Crouch"))
        {
            crouch = true;
        }
        else if (Input.GetButtonUp("Crouch"))
        {
            crouch = false;
        }*/ // comment to stop crouch

        if (player.GetComponent<PlayerMovementController>().isAttacking && !alreadyAttacking)
        {
            if (player && transform)
            {
                alreadyAttacking = true;
                // Convert to JSON object
                string requestData =
                    "{" +
                    "\"aiHealth\": \"" + transform.GetComponentInParent<HealthController>().health + "\"" +
                    ", \"playerHealth\":\"" + player.GetComponent<HealthController>().health + "\"" +
                    "}";

                // Call AI api to check and get score
                StartCoroutine(PostRequest((success, response) =>
                    {
                        alreadyAttacking = false;
                        if (success)
                        {
                            // Create image from the response data
                            //Debug.Log(response);
                            Response<AIResponse> res = JsonUtility.FromJson<Response<AIResponse>>(response);

                            Debug.Log(res.data.action);
                            Debug.Log(res.data.score);
                            transform.GetComponentInChildren<AIActionController>().Attack(res.data.score);
                        }
                        else
                        {
                            Debug.Log(response);

                            if (notification)
                            {
                                StopAllCoroutines();
                                notification.GetComponent<Text>().text =
                                    "Something went wrong with the server.";
                                notification.SetActive(true);
                                StartCoroutine(FadeOutNotification());
                            }
                        }

                        //"http://codebreaker-cv.us-west-2.elasticbeanstalk.com"
                    }, requestData, "http://localhost:5000",
                    "/play/ai"));
            }
        }
    }

    IEnumerator FadeOutNotification()
    {
        yield return new WaitForSeconds(1f);

        /*for (float f = 1f; f >= 0; f -= 0.1f)
        {
            f = (float) Math.Round(f, 1);
//                Debug.Log("FadeOut: " + f);*/
        notification.SetActive(false);
        /*yield return null;
    }*/
    }

    ///<summary>
    /// Takes callback function, serverAddress and requestURL as string, request data as  JSON string
    /// POST request using WWW class
    /// </summary>
    IEnumerator PostRequest(Action<bool, string> callback,
        string jsonDataString = "{\"aiHealth\":100,\"playerHealth\":\"100\"}",
        string serverAddress = "http://localhost:5000",
        string requestURL = "/play/ai")
    {
        bool retVal;
        string response;
        Dictionary<string, string> headers = new Dictionary<string, string>();
        headers.Add("Content-Type", "application/json");
        Debug.Log(jsonDataString);
        byte[] byteData = Encoding.ASCII.GetBytes(jsonDataString.ToCharArray());
        WWW www = new WWW(serverAddress + requestURL, byteData, headers);
        yield return www;
        if (string.IsNullOrEmpty(www.error))
        {
            retVal = true;
            response = www.text;
//                Debug.Log(www.text);
        }
        else
        {
            retVal = false;
            response = www.error;
//                Debug.Log(www.error);
        }

        callback(retVal, response);
    }

    ///<summary>
    /// Takes callback function, serverAddress and requestURL as string
    /// GET request using WWW class
    /// </summary>
    IEnumerator GetRequest(Action<bool, string> callback, string serverAddress = "http://localhost:5000",
        string requestURL = "/test")
    {
        bool retVal;
        string response;
        WWW www = new WWW(serverAddress + requestURL);
        while (!www.isDone)
            yield return null;

        if (string.IsNullOrEmpty(www.error))
        {
            retVal = true;
            response = www.text;
//                Debug.Log(www.text);
        }
        else
        {
            retVal = false;
            response = www.error;
//                Debug.Log(www.error);
        }

        callback(retVal, response);
    }

    public void OnLanding()
    {
        animator.SetBool("IsJumping", false);
    }

    void FixedUpdate()
    {
        controller.Move(horizontalMove * Time.fixedDeltaTime, crouch, jump);
        jump = false;
    }
}