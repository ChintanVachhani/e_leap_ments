﻿using System;
using System.Collections;
using System.Collections.Generic;
using System.Text;
using UnityEngine;
using UnityEngine.UI;

public class PlayerMovementController : MonoBehaviour
{
    public CharacterController2D controller;
    public Animator animator;

    private float horizontalMove = 0f;
    [HideInInspector] public bool jump = false;
    [HideInInspector] public bool crouch = false;

    [HideInInspector] public string action;
    [HideInInspector] public bool isAttacking;
    public GameObject canvas;
    [HideInInspector] public UIController uiController;
    public GameObject notification;

    // Start is called before the first frame update
    void Start()
    {
        uiController = canvas.GetComponent<UIController>();
        isAttacking = false;
    }

    // Update is called once per frame
    void Update()
    {
        // horizontalMove = Input.GetAxisRaw("Horizontal"); // comment to stop horizontal movement

        if (Input.GetButtonDown("Jump"))
        {
            jump = true;
            animator.SetBool("IsJumping", true);
        }

        if (Input.GetButtonDown("Crouch"))
        {
            crouch = true;
            animator.SetBool("IsCrouching", true);
        }
        else if (Input.GetButtonUp("Crouch"))
        {
            crouch = false;
        }

        if (Input.GetButtonDown("A"))
        {
            action += "A";
            uiController.air.gameObject.SetActive(true);
        }

        if (Input.GetButtonDown("B"))
        {
            action += "B";
            uiController.fire.gameObject.SetActive(true);
        }

        if (Input.GetButtonDown("C"))
        {
            action += "C";
            uiController.earth.gameObject.SetActive(true);
        }

        if (Input.GetButtonDown("D"))
        {
            action += "D";
            uiController.water.gameObject.SetActive(true);
        }

        if ((Input.GetButtonDown("Fire1") && action.Length > 0) || action.Length == 4)
        {
            isAttacking = true;
            // Convert to JSON object
            string requestData =
                "{" +
                "\"action\": \"" + action + "\"" +
                ", \"health\":\"" + transform.GetComponentInParent<HealthController>().health + "\"" +
                "}";

            // Call AI api to check and get score
            StartCoroutine(PostRequest((success, response) =>
                {
                    isAttacking = false;
                    if (success)
                    {
                        // Create image from the response data
                        //Debug.Log(response);
                        Response<UserResponse> res = JsonUtility.FromJson<Response<UserResponse>>(response);

                        transform.GetComponentInChildren<PlayerActionController>().Attack(res.data.score);
                    }
                    else
                    {
                        Debug.Log(response);

                        if (notification)
                        {
                            StopAllCoroutines();
                            notification.GetComponent<Text>().text =
                                "Something went wrong with the server.";
                            notification.SetActive(true);
                            StartCoroutine(FadeOutNotification());
                        }
                    }

                    //"http://codebreaker-cv.us-west-2.elasticbeanstalk.com"
                }, requestData, "http://localhost:5000",
                "/play/user"));
            action = "";
            StartCoroutine(FadeOutElements());
        }
    }

    IEnumerator FadeOutNotification()
    {
        yield return new WaitForSeconds(1f);

        /*for (float f = 1f; f >= 0; f -= 0.1f)
        {
            f = (float) Math.Round(f, 1);
//                Debug.Log("FadeOut: " + f);*/
        notification.SetActive(false);
        /*yield return null;
    }*/
    }

    IEnumerator FadeOutElements()
    {
        yield return new WaitForSeconds(1f);

        /*for (float f = 1f; f >= 0; f -= 0.1f)
        {
            f = (float) Math.Round(f, 1);
//                Debug.Log("FadeOut: " + f);*/
        uiController.water.gameObject.SetActive(false);
        uiController.earth.gameObject.SetActive(false);
        uiController.fire.gameObject.SetActive(false);
        uiController.air.gameObject.SetActive(false);
        /*yield return null;
    }*/
    }

    public void OnLanding()
    {
        animator.SetBool("IsJumping", false);
    }

    public void OnCrouching(bool isCrouching)
    {
        animator.SetBool("IsCrouching", isCrouching);
    }

    void FixedUpdate()
    {
        controller.Move(horizontalMove * Time.fixedDeltaTime, crouch, jump);
        jump = false;
    }

    ///<summary>
    /// Takes callback function, serverAddress and requestURL as string, request data as  JSON string
    /// POST request using WWW class
    /// </summary>
    IEnumerator PostRequest(Action<bool, string> callback,
        string jsonDataString = "{\"action\":ABCD,\"health\":\"100\"}",
        string serverAddress = "http://localhost:5000",
        string requestURL = "/play/user")
    {
        bool retVal;
        string response;
        Dictionary<string, string> headers = new Dictionary<string, string>();
        headers.Add("Content-Type", "application/json");
        Debug.Log(jsonDataString);
        byte[] byteData = Encoding.ASCII.GetBytes(jsonDataString.ToCharArray());
        WWW www = new WWW(serverAddress + requestURL, byteData, headers);
        yield return www;
        if (string.IsNullOrEmpty(www.error))
        {
            retVal = true;
            response = www.text;
//                Debug.Log(www.text);
        }
        else
        {
            retVal = false;
            response = www.error;
//                Debug.Log(www.error);
        }

        callback(retVal, response);
    }

    ///<summary>
    /// Takes callback function, serverAddress and requestURL as string
    /// GET request using WWW class
    /// </summary>
    IEnumerator GetRequest(Action<bool, string> callback, string serverAddress = "http://localhost:5000",
        string requestURL = "/test")
    {
        bool retVal;
        string response;
        WWW www = new WWW(serverAddress + requestURL);
        while (!www.isDone)
            yield return null;

        if (string.IsNullOrEmpty(www.error))
        {
            retVal = true;
            response = www.text;
//                Debug.Log(www.text);
        }
        else
        {
            retVal = false;
            response = www.error;
//                Debug.Log(www.error);
        }

        callback(retVal, response);
    }
}