﻿using System.Collections;
using System.Collections.Generic;
using Leap.Unity;
using UnityEngine;

public class GestureController : MonoBehaviour
{
    public GameObject player;
    private PlayerMovementController playerMovementController;

    // Use this for initialization
    void Start()
    {
        playerMovementController = player.GetComponent<PlayerMovementController>();
    }

    // Update is called once per frame
    void Update()
    {
    }

    public void fireAction()
    {
        playerMovementController.action += "B";
        playerMovementController.uiController.fire.gameObject.SetActive(true);
    }

    public void airAction()
    {
        playerMovementController.action += "A";
        playerMovementController.uiController.air.gameObject.SetActive(true);
    }

    public void earthAction()
    {
        playerMovementController.action += "C";
        playerMovementController.uiController.earth.gameObject.SetActive(true);
    }

    public void waterAction()
    {
        playerMovementController.action += "D";
        playerMovementController.uiController.water.gameObject.SetActive(true);
    }

    public void jumpAction()
    {
        Debug.Log("Jump!");
        playerMovementController.jump = true;
        playerMovementController.animator.SetBool("IsJumping", true);
    }

    public void crouch()
    {
        playerMovementController.crouch = true;
        playerMovementController.animator.SetBool("IsCrouching", true);
    }

    public void crouchUp()
    {
        playerMovementController.crouch = false;
    }
}